import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-north',
  templateUrl: './north.component.html',
  styleUrls: ['./north.component.css']
})
export class NorthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
