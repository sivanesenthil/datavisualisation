import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-continental',
  templateUrl: './continental.component.html',
  styleUrls: ['./continental.component.css']
})
export class ContinentalComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
