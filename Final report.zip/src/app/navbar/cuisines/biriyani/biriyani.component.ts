import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-biriyani',
  templateUrl: './biriyani.component.html',
  styleUrls: ['./biriyani.component.css']
})
export class BiriyaniComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
