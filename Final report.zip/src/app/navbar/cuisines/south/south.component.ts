import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-south',
  templateUrl: './south.component.html',
  styleUrls: ['./south.component.css']
})
export class SouthComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
