import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-andhra',
  templateUrl: './andhra.component.html',
  styleUrls: ['./andhra.component.css']
})
export class AndhraComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  imageSource:string=" ";
}
