import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-up',
  templateUrl: './up.component.html',
  styleUrls: ['./up.component.css']
})
export class UpComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  imageSource:string=" ";
}
