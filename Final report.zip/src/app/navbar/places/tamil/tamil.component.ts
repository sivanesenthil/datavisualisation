import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-tamil',
  templateUrl: './tamil.component.html',
  styleUrls: ['./tamil.component.css']
})
export class TamilComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  imageSource:string=" ";
}
