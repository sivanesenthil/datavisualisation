import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-telengana',
  templateUrl: './telengana.component.html',
  styleUrls: ['./telengana.component.css']
})
export class TelenganaComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  imageSource:string=" ";
}
