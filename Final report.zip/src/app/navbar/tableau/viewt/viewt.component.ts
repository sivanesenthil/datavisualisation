import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewt',
  templateUrl: './viewt.component.html',
  styleUrls: ['./viewt.component.css']
})
export class ViewtComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
