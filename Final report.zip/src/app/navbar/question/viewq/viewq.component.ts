import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-viewq',
  templateUrl: './viewq.component.html',
  styleUrls: ['./viewq.component.css']
})
export class ViewqComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }
  imageSource:string=" ";
}
